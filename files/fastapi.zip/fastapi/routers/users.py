from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter(tags=["Users"])

class User(BaseModel):
    id: int
    name: str
    surname: str
    age: int
    url: str

users_list=[User(id=1,name="Salvador", surname="Cuamatzi", age=44, url="scuamatzi.net"),
            User(id=2,name="Bruno", surname="Cuamatzi", age=6, url="bcuamatzi.net"),
            User(id=3,name="Abril", surname="Aldape", age=16, url="aaldape.net")]

@router.get("/users")
async def users():
    return users_list

@router.get("/user/{id}")
async def user(id: int):
    return search_user(id)


@router.get("/user/")
async def userquery(id: int):
    return search_user(id)


@router.post("/user/",response_model=User, status_code=201)
async def useradd(user: User):
    if type(search_user(user.id))==User:
        raise HTTPException(status_code=404, detail="El usuario ya existe")
        ##return {"error" : "El usuario ya existe"}
    else:
        users_list.append(user)
        return user

@router.put("/user/")
async def userupdate(user: User):
    found = False

    for index, saved_user in enumerate(users_list):
        if saved_user.id == user.id:
            users_list[index]=user
            found = True
    
    if not found:
        return {"error":"No se ha podido actualizar el usuario"}
    else:
        return user

@router.delete("/user/{id}")
async def userdel(id: int):
    found = False

    for index, saved_user in enumerate(users_list):
        if saved_user.id == id:
            del users_list[index]
            found = True
    
    if not found:
        return {"error":"No se ha eliminado el usuario"}

def search_user(id: int):
    users_result=filter(lambda usuario: usuario.id==id, users_list)
    try:
        return list(users_result)[0]
        #return list(users_result)
    except:
        value="No se ha encontrado el usuario " + str(id)
        #return {"error": "No se ha encontrado el usuario"}
        return {"error": value}

## start server with uvicorn users:app --reload

## Documentation with Swagger : localhost:8000/docs
## Documentation with Redocly : localhost:8000/redoc



"""
{
	"id": 4,
	"name": "Silvia",
	"surname": "Gonzalez",
	"age": 16,
	"url": "silvia.com.mx"
}

{
	"id": 5,
	"name": "Frida",
	"surname": "Gonzalez",
	"age": 17,
	"url": "alex.com.mx"
}

{
	"id": 6,
	"name": "alejandro",
	"surname": "cuamatzi",
	"age": 4,
	"url": "alex.com.mx"
}


"""