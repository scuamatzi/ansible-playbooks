#value=01
value=1

print(value)
